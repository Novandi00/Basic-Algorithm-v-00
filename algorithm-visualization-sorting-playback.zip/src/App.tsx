import { useState, useEffect, useRef, useCallback } from 'react';

type SortStep = {
  array: number[];
  comparing: number[];
  swapping: number[];
  sorted: number[];
  pivot?: number;
  description: string;
};

type Algorithm = 'bubble' | 'quick' | 'merge';

// Generate sorting steps for Bubble Sort
function bubbleSortSteps(arr: number[]): SortStep[] {
  const steps: SortStep[] = [];
  const array = [...arr];
  const sorted: number[] = [];
  
  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: [],
    description: 'Starting Bubble Sort'
  });

  for (let i = 0; i < array.length - 1; i++) {
    for (let j = 0; j < array.length - i - 1; j++) {
      steps.push({
        array: [...array],
        comparing: [j, j + 1],
        swapping: [],
        sorted: [...sorted],
        description: `Comparing elements at index ${j} (${array[j]}) and ${j + 1} (${array[j + 1]})`
      });

      if (array[j] > array[j + 1]) {
        steps.push({
          array: [...array],
          comparing: [],
          swapping: [j, j + 1],
          sorted: [...sorted],
          description: `Swapping ${array[j]} and ${array[j + 1]}`
        });
        [array[j], array[j + 1]] = [array[j + 1], array[j]];
        
        steps.push({
          array: [...array],
          comparing: [],
          swapping: [],
          sorted: [...sorted],
          description: `Swapped! Array is now: [${array.join(', ')}]`
        });
      }
    }
    sorted.unshift(array.length - i - 1);
  }
  sorted.unshift(0);

  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: Array.from({ length: array.length }, (_, i) => i),
    description: 'Bubble Sort complete!'
  });

  return steps;
}

// Generate sorting steps for Quick Sort
function quickSortSteps(arr: number[]): SortStep[] {
  const steps: SortStep[] = [];
  const array = [...arr];
  const sorted: number[] = [];

  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: [],
    description: 'Starting Quick Sort'
  });

  function partition(low: number, high: number): number {
    const pivot = array[high];
    steps.push({
      array: [...array],
      comparing: [],
      swapping: [],
      sorted: [...sorted],
      pivot: high,
      description: `Choosing pivot: ${pivot} at index ${high}`
    });

    let i = low - 1;

    for (let j = low; j < high; j++) {
      steps.push({
        array: [...array],
        comparing: [j, high],
        swapping: [],
        sorted: [...sorted],
        pivot: high,
        description: `Comparing ${array[j]} with pivot ${pivot}`
      });

      if (array[j] < pivot) {
        i++;
        if (i !== j) {
          steps.push({
            array: [...array],
            comparing: [],
            swapping: [i, j],
            sorted: [...sorted],
            pivot: high,
            description: `${array[j]} < ${pivot}, swapping elements at index ${i} and ${j}`
          });
          [array[i], array[j]] = [array[j], array[i]];
        }
      }
    }

    if (i + 1 !== high) {
      steps.push({
        array: [...array],
        comparing: [],
        swapping: [i + 1, high],
        sorted: [...sorted],
        description: `Placing pivot ${pivot} in its final position at index ${i + 1}`
      });
      [array[i + 1], array[high]] = [array[high], array[i + 1]];
    }

    sorted.push(i + 1);
    return i + 1;
  }

  function quickSort(low: number, high: number) {
    if (low < high) {
      const pi = partition(low, high);
      quickSort(low, pi - 1);
      quickSort(pi + 1, high);
    } else if (low === high) {
      sorted.push(low);
    }
  }

  quickSort(0, array.length - 1);

  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: Array.from({ length: array.length }, (_, i) => i),
    description: 'Quick Sort complete!'
  });

  return steps;
}

// Generate sorting steps for Merge Sort
function mergeSortSteps(arr: number[]): SortStep[] {
  const steps: SortStep[] = [];
  const array = [...arr];

  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: [],
    description: 'Starting Merge Sort'
  });

  function merge(left: number, mid: number, right: number) {
    const leftArr = array.slice(left, mid + 1);
    const rightArr = array.slice(mid + 1, right + 1);

    steps.push({
      array: [...array],
      comparing: Array.from({ length: right - left + 1 }, (_, i) => left + i),
      swapping: [],
      sorted: [],
      description: `Merging subarrays [${left}..${mid}] and [${mid + 1}..${right}]`
    });

    let i = 0, j = 0, k = left;

    while (i < leftArr.length && j < rightArr.length) {
      steps.push({
        array: [...array],
        comparing: [left + i, mid + 1 + j],
        swapping: [],
        sorted: [],
        description: `Comparing ${leftArr[i]} and ${rightArr[j]}`
      });

      if (leftArr[i] <= rightArr[j]) {
        array[k] = leftArr[i];
        i++;
      } else {
        array[k] = rightArr[j];
        j++;
      }
      k++;
      
      steps.push({
        array: [...array],
        comparing: [],
        swapping: [],
        sorted: [],
        description: `Placed element, array: [${array.join(', ')}]`
      });
    }

    while (i < leftArr.length) {
      array[k] = leftArr[i];
      i++;
      k++;
    }

    while (j < rightArr.length) {
      array[k] = rightArr[j];
      j++;
      k++;
    }

    steps.push({
      array: [...array],
      comparing: [],
      swapping: [],
      sorted: [],
      description: `Merged! Subarray [${left}..${right}] is now [${array.slice(left, right + 1).join(', ')}]`
    });
  }

  function mergeSort(left: number, right: number) {
    if (left < right) {
      const mid = Math.floor((left + right) / 2);
      mergeSort(left, mid);
      mergeSort(mid + 1, right);
      merge(left, mid, right);
    }
  }

  mergeSort(0, array.length - 1);

  steps.push({
    array: [...array],
    comparing: [],
    swapping: [],
    sorted: Array.from({ length: array.length }, (_, i) => i),
    description: 'Merge Sort complete!'
  });

  return steps;
}

// Generate random array
function generateRandomArray(size: number): number[] {
  return Array.from({ length: size }, () => Math.floor(Math.random() * 100) + 1);
}

// Generate nearly sorted array
function generateNearlySortedArray(size: number): number[] {
  const arr = Array.from({ length: size }, (_, i) => i + 1);
  for (let i = 0; i < size / 5; i++) {
    const idx1 = Math.floor(Math.random() * size);
    const idx2 = Math.floor(Math.random() * size);
    [arr[idx1], arr[idx2]] = [arr[idx2], arr[idx1]];
  }
  return arr;
}

// Generate reversed array
function generateReversedArray(size: number): number[] {
  return Array.from({ length: size }, (_, i) => size - i);
}

export default function App() {
  const [array, setArray] = useState<number[]>([]);
  const [arraySize, setArraySize] = useState(20);
  const [algorithm, setAlgorithm] = useState<Algorithm>('bubble');
  const [steps, setSteps] = useState<SortStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(50);
  const [arrayType, setArrayType] = useState<'random' | 'nearlySorted' | 'reversed'>('random');
  
  const animationRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Initialize array on mount and when size/type changes
  useEffect(() => {
    generateNewArray();
  }, [arraySize, arrayType]);

  // Generate new array based on type
  const generateNewArray = () => {
    setIsPlaying(false);
    setCurrentStep(0);
    setSteps([]);
    
    let newArray: number[];
    switch (arrayType) {
      case 'nearlySorted':
        newArray = generateNearlySortedArray(arraySize);
        break;
      case 'reversed':
        newArray = generateReversedArray(arraySize);
        break;
      default:
        newArray = generateRandomArray(arraySize);
    }
    setArray(newArray);
  };

  // Generate steps for current algorithm
  const generateSteps = useCallback(() => {
    let newSteps: SortStep[];
    switch (algorithm) {
      case 'bubble':
        newSteps = bubbleSortSteps(array);
        break;
      case 'quick':
        newSteps = quickSortSteps(array);
        break;
      case 'merge':
        newSteps = mergeSortSteps(array);
        break;
      default:
        newSteps = bubbleSortSteps(array);
    }
    setSteps(newSteps);
    setCurrentStep(0);
  }, [array, algorithm]);

  // Animation loop
  useEffect(() => {
    if (isPlaying && steps.length > 0) {
      const animate = (timestamp: number) => {
        const delay = 1000 - (speed * 9.5);
        if (timestamp - lastTimeRef.current >= delay) {
          setCurrentStep(prev => {
            if (prev >= steps.length - 1) {
              setIsPlaying(false);
              return prev;
            }
            return prev + 1;
          });
          lastTimeRef.current = timestamp;
        }
        animationRef.current = requestAnimationFrame(animate);
      };
      animationRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, steps.length, speed]);

  const handlePlay = () => {
    if (steps.length === 0) {
      generateSteps();
    }
    setIsPlaying(true);
    lastTimeRef.current = performance.now();
  };

  const handlePause = () => {
    setIsPlaying(false);
  };

  const handleStepForward = () => {
    if (steps.length === 0) {
      generateSteps();
    }
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleStepBackward = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStep(0);
  };

  const handleNewArray = () => {
    generateNewArray();
  };

  const handleAlgorithmChange = (algo: Algorithm) => {
    setAlgorithm(algo);
    setIsPlaying(false);
    setCurrentStep(0);
    setSteps([]);
  };

  const currentStepData = steps[currentStep] || {
    array: array,
    comparing: [],
    swapping: [],
    sorted: [],
    description: 'Click "Generate Steps" or "Play" to start visualization'
  };

  const displayArray = currentStepData.array.length > 0 ? currentStepData.array : array;
  const maxValue = Math.max(...displayArray, 1);

  const getBarColor = (index: number) => {
    if (currentStepData.sorted.includes(index)) {
      return 'bg-emerald-500';
    }
    if (currentStepData.pivot === index) {
      return 'bg-purple-500';
    }
    if (currentStepData.swapping.includes(index)) {
      return 'bg-red-500';
    }
    if (currentStepData.comparing.includes(index)) {
      return 'bg-yellow-500';
    }
    return 'bg-indigo-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
            Sorting Algorithm Visualizer
          </h1>
          <p className="text-slate-400">
            Watch how different sorting algorithms organize data step by step
          </p>
        </div>

        {/* Controls Panel */}
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-6 border border-slate-700/50">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Algorithm Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Algorithm</label>
              <div className="flex gap-2">
                {(['bubble', 'quick', 'merge'] as Algorithm[]).map((algo) => (
                  <button
                    key={algo}
                    onClick={() => handleAlgorithmChange(algo)}
                    className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      algorithm === algo
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {algo.charAt(0).toUpperCase() + algo.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Array Type */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Array Type</label>
              <select
                value={arrayType}
                onChange={(e) => setArrayType(e.target.value as typeof arrayType)}
                className="w-full px-3 py-2 rounded-lg bg-slate-700 text-slate-300 border border-slate-600 focus:border-indigo-500 focus:outline-none"
              >
                <option value="random">Random</option>
                <option value="nearlySorted">Nearly Sorted</option>
                <option value="reversed">Reversed</option>
              </select>
            </div>

            {/* Array Size */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">
                Array Size: {arraySize}
              </label>
              <input
                type="range"
                min="5"
                max="50"
                value={arraySize}
                onChange={(e) => setArraySize(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>

            {/* Speed Control */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">
                Speed: {speed}%
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={speed}
                onChange={(e) => setSpeed(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 mt-6">
            <button
              onClick={handleNewArray}
              className="px-4 py-2 rounded-lg bg-slate-700 text-slate-200 hover:bg-slate-600 transition-colors font-medium"
            >
              New Array
            </button>
            <button
              onClick={generateSteps}
              className="px-4 py-2 rounded-lg bg-violet-600 text-white hover:bg-violet-500 transition-colors font-medium"
            >
              Generate Steps
            </button>
          </div>
        </div>

        {/* Visualization Area */}
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-6 border border-slate-700/50">
          {/* Playback Controls */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <button
              onClick={handleReset}
              className="p-3 rounded-xl bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
              title="Reset"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
            <button
              onClick={handleStepBackward}
              disabled={currentStep === 0}
              className="p-3 rounded-xl bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="Step Back"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.333 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" />
              </svg>
            </button>
            {isPlaying ? (
              <button
                onClick={handlePause}
                className="p-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-500/30"
                title="Pause"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </button>
            ) : (
              <button
                onClick={handlePlay}
                className="p-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-500/30"
                title="Play"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </button>
            )}
            <button
              onClick={handleStepForward}
              disabled={steps.length > 0 && currentStep >= steps.length - 1}
              className="p-3 rounded-xl bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="Step Forward"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.933 12.8a1 1 0 000-1.6L6.6 7.2A1 1 0 005 8v8a1 1 0 001.6.8l5.333-4zM19.933 12.8a1 1 0 000-1.6l-5.333-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.333-4z" />
              </svg>
            </button>
          </div>

          {/* Step Progress */}
          {steps.length > 0 && (
            <div className="mb-6">
              <div className="flex justify-between text-sm text-slate-400 mb-2">
                <span>Step {currentStep + 1} of {steps.length}</span>
                <span>{Math.round((currentStep / (steps.length - 1)) * 100) || 0}% Complete</span>
              </div>
              <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-200"
                  style={{ width: `${steps.length > 1 ? (currentStep / (steps.length - 1)) * 100 : 0}%` }}
                />
              </div>
            </div>
          )}

          {/* Description */}
          <div className="mb-6 p-4 rounded-xl bg-slate-700/50 border border-slate-600/50">
            <p className="text-center text-slate-200 font-medium">
              {currentStepData.description}
            </p>
          </div>

          {/* Bars Visualization */}
          <div className="flex items-end justify-center gap-1 h-64 md:h-80 px-2">
            {displayArray.map((value, index) => (
              <div
                key={index}
                className={`transition-all duration-100 rounded-t-sm ${getBarColor(index)}`}
                style={{
                  height: `${(value / maxValue) * 100}%`,
                  width: `${Math.max(100 / displayArray.length - 1, 4)}%`,
                  minWidth: '4px',
                  maxWidth: '30px'
                }}
                title={`Index ${index}: ${value}`}
              />
            ))}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap justify-center gap-4 mt-6 pt-4 border-t border-slate-700/50">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-indigo-500" />
              <span className="text-sm text-slate-400">Unsorted</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-yellow-500" />
              <span className="text-sm text-slate-400">Comparing</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-red-500" />
              <span className="text-sm text-slate-400">Swapping</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-purple-500" />
              <span className="text-sm text-slate-400">Pivot</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-emerald-500" />
              <span className="text-sm text-slate-400">Sorted</span>
            </div>
          </div>
        </div>

        {/* Algorithm Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className={`p-4 rounded-xl border transition-all ${algorithm === 'bubble' ? 'bg-indigo-900/30 border-indigo-500/50' : 'bg-slate-800/50 border-slate-700/50'}`}>
            <h3 className="font-semibold text-white mb-2">Bubble Sort</h3>
            <p className="text-sm text-slate-400">Time: O(n²) | Space: O(1)</p>
            <p className="text-sm text-slate-500 mt-1">Repeatedly swaps adjacent elements if they're in the wrong order.</p>
          </div>
          <div className={`p-4 rounded-xl border transition-all ${algorithm === 'quick' ? 'bg-indigo-900/30 border-indigo-500/50' : 'bg-slate-800/50 border-slate-700/50'}`}>
            <h3 className="font-semibold text-white mb-2">Quick Sort</h3>
            <p className="text-sm text-slate-400">Time: O(n log n) | Space: O(log n)</p>
            <p className="text-sm text-slate-500 mt-1">Divides array using a pivot, then recursively sorts partitions.</p>
          </div>
          <div className={`p-4 rounded-xl border transition-all ${algorithm === 'merge' ? 'bg-indigo-900/30 border-indigo-500/50' : 'bg-slate-800/50 border-slate-700/50'}`}>
            <h3 className="font-semibold text-white mb-2">Merge Sort</h3>
            <p className="text-sm text-slate-400">Time: O(n log n) | Space: O(n)</p>
            <p className="text-sm text-slate-500 mt-1">Divides array in halves, sorts them, then merges back together.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-slate-500 text-sm pb-4">
          Adjust the speed and array size to explore how algorithms behave with different inputs
        </div>
      </div>
    </div>
  );
}
